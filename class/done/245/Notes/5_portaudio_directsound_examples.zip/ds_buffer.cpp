// ds_buffer.cpp
// -- simple usage of a DirectSound buffer
// jsh 5/09
//
// usage:
//   ds_buffer <file>
// where:
//   <file> -- WAV file (any format)
//
// Must be linked with:
//   dsound.lib dxguid.lib user32.lib


#include <iostream>
#include <fstream>
#include <cstring>
#include <conio.h>
#include <windows.h>
#include <dsound.h>
using namespace std;


int main(int argc, char* argv[]) {
  if (argc != 2)
    return 0;

  char *title = "sound";
  SetConsoleTitle(title);
  Sleep(40);
  HWND window = FindWindow(0,title);

  fstream in(argv[1],ios_base::binary|ios_base::in);
  char header[40];
  in.read(header,sizeof(header));
  unsigned data_size;
  in.read(reinterpret_cast<char*>(&data_size),4);
  char *data = new char[data_size];
  in.read(data,data_size);
  WAVEFORMATEX wf;
  memcpy(&wf,header+20,sizeof(wf));
  wf.cbSize = 0;

  LPDIRECTSOUND8 ds;
  DirectSoundCreate8(0,&ds,0);
  ds->SetCooperativeLevel(window,DSSCL_NORMAL);
  DSBUFFERDESC desc;
  ZeroMemory(&desc,sizeof(desc));
  desc.dwSize = sizeof(desc);
  desc.dwFlags = DSBCAPS_CTRLVOLUME | DSBCAPS_GLOBALFOCUS;
  desc.lpwfxFormat = &wf;
  desc.dwBufferBytes = data_size;
  LPDIRECTSOUNDBUFFER dsb;
  ds->CreateSoundBuffer(&desc,&dsb,0);
  LPDIRECTSOUNDBUFFER8 dsb8;
  dsb->QueryInterface(IID_IDirectSoundBuffer8,(LPVOID*)&dsb8);
  dsb->Release();

  void *addr;
  DWORD bytes;
  dsb8->Lock(0,0,&addr,&bytes,0,0,DSBLOCK_ENTIREBUFFER);
  memcpy(addr,data,data_size);
  dsb8->Unlock(addr,bytes,0,0);

  DWORD status;
  dsb8->Play(0,0,0);
  cout << "hit a key to stop playing ";
  do {
    Sleep(1000);
    cout << '.';
    dsb8->GetStatus(&status); }
  while (!_kbhit() && status&DSBSTATUS_PLAYING);
  if (_kbhit())
    _getch();

  dsb8->Stop();
  dsb8->Release();
  delete[] data;
  return 0;
}
