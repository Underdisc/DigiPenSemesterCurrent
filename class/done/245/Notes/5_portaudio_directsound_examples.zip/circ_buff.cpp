// circ_buff.cpp
// -- circular buffer
// jsh 5/09, mod 1/14
//
// usage:
//   circ_buff [freq]
// where:
//   [freq] -- (optional) frequency
// to quit:
//   hit any key
//
// Compilation note:
//   needs 'dsound.lib', 'dxguid.lib', 'user32.lib'

#include <iostream>

#include <cmath>
#include <cstdlib>
#include <conio.h>
#include <windows.h>
#include <dsound.h>
using namespace std;


// class for generating successive audio samples
class Warble {
  public:
    Warble(float frequency, int sample_rate);
    short operator()(void);
  private:
    const float rate, amplitude;
    int index;
};


Warble::Warble(float f, int r)
    : rate(8.0f*atan(1.0f)*f/r), amplitude((1<<15)-1), index(0) {
}


short Warble::operator()(void) {
  float angle = rate*index * sin(0.001f*rate*index);
  float y = 0.8f * amplitude * sin(angle);
  ++index;
  return short(y);
}



int main(int argc, char* argv[]) {
  if (argc != 1 && argc != 2)
    return 0;

  float frequency = 440.0f;
  if (argc == 2)
    frequency = float(atof(argv[1]));

  // get handle of console window
  const char *title = "circ_buff";
  SetConsoleTitle(title);
  Sleep(40);
  HWND window = FindWindow(0,title);

  // specify the audio sample format
  WAVEFORMATEX waveformat;
  waveformat.wFormatTag = WAVE_FORMAT_PCM;
  waveformat.nChannels = 1;
  waveformat.nSamplesPerSec = 44100;
  waveformat.wBitsPerSample = 16;
  waveformat.nBlockAlign = waveformat.nChannels
                           * waveformat.wBitsPerSample/8;
  waveformat.nAvgBytesPerSec = waveformat.nSamplesPerSec
                               * waveformat.nBlockAlign;
  waveformat.cbSize = 0;

  // create a buffer
  LPDIRECTSOUND8 ds;
  DirectSoundCreate8(0,&ds,0);
  ds->SetCooperativeLevel(window,DSSCL_NORMAL);
  DSBUFFERDESC desc;
  ZeroMemory(&desc,sizeof(desc));
  desc.dwSize = sizeof(desc);
  desc.dwFlags = DSBCAPS_CTRLVOLUME|DSBCAPS_GLOBALFOCUS;
  desc.lpwfxFormat = &waveformat;
  desc.dwBufferBytes = waveformat.nAvgBytesPerSec;
  LPDIRECTSOUNDBUFFER dsb;
  ds->CreateSoundBuffer(&desc,&dsb,0);
  LPDIRECTSOUNDBUFFER8 dsb8;
  dsb->QueryInterface(IID_IDirectSoundBuffer8,(LPVOID*)&dsb8);
  dsb->Release();

  // initialize data in buffer
  Warble warble(frequency,waveformat.nSamplesPerSec);
  void *vaddress;
  DWORD buffer_sz;
  dsb8->Lock(0,0,&vaddress,&buffer_sz,0,0,DSBLOCK_ENTIREBUFFER);
  short *address = reinterpret_cast<short*>(vaddress);
  unsigned sample_count = buffer_sz/2;
  for (unsigned i=0; i < sample_count; ++i)
    address[i] = warble();
  dsb8->Unlock(vaddress,buffer_sz,0,0);

  // play the buffer
  dsb8->Play(0,0,DSBPLAY_LOOPING);
  DWORD ilast = 0;
  while (!_kbhit()) {
    Sleep(50);
    DWORD iplay;
    dsb8->GetCurrentPosition(&iplay,0);
    DWORD bytes_to_write = (ilast <= iplay)
                           ? iplay - ilast
                           : buffer_sz - ilast + iplay;
    DWORD bytes1, bytes2;
    void *vaddress1, *vaddress2;
    dsb8->Lock(ilast,bytes_to_write,&vaddress1,&bytes1,
                                    &vaddress2,&bytes2,0);
    address = reinterpret_cast<short*>(vaddress1);
    sample_count = bytes1/2;
    for (unsigned i=0; i < sample_count; ++i)
      address[i] = warble();
    address = reinterpret_cast<short*>(vaddress2);
    sample_count = bytes2/2;
    for (unsigned i=0; i < sample_count; ++i)
      address[i] = warble();
    dsb8->Unlock(vaddress1,bytes1,vaddress2,bytes2);
    ilast = (ilast + bytes_to_write)%buffer_sz;
  }

  // stop playing and clean up
  _getch();
  dsb8->Stop();
  dsb8->Release();
  ds->Release();
  return 0;
}
