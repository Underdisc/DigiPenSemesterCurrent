// wave_write.cpp
// -- write a .WAV file
// jsh 1/18
//
// usage:
//   wave_write <sampling rate> <# of channels> <# bits per sample>
// where:
//   <sampling rate>     -- 44100, or 22050 (others may work)
//   <# of channels>     -- 1 (mono) or 2 (stereo)
//   <# bits per sample> -- 16 or 8
// output:
//   'wave_write.wav'
// assumes:
//   short = 16 bits, little-endian architecture

#include <fstream>
#include <cmath>
#include <cstdlib>
using namespace std;


int main(int argc, char *argv[]) {
  if (argc != 4)
    return 0;

  unsigned rate     = atoi(argv[1]),
           channels = atoi(argv[2]),
           bps      = atoi(argv[3]);
  int frame_count = 2*rate, // 2 seconds of audio
      data_size = frame_count*channels*bps/8;
  float pi = 4.0f*atan(1.0f),
        frequency = 440.0f,
        omega = 2.0f*pi*frequency/rate;

  struct {
    char riff_chunk[4];
    unsigned chunk_size;
    char wave_fmt[4];
    char fmt_chunk[4];
    unsigned fmt_chunk_size;
    unsigned short audio_format;
    unsigned short number_of_channels;
    unsigned sampling_rate;
    unsigned bytes_per_second;
    unsigned short block_align;
    unsigned short bits_per_sample;
    char data_chunk[4];
    unsigned data_chunk_size;
  }
  header = { {'R','I','F','F'},
             36 + data_size,
               {'W','A','V','E'},
               {'f','m','t',' '},
               16,
                 1,
                 channels,
                 rate,
                 rate*channels*bps/8,
                 channels*bps/8,
                 bps,
               {'d','a','t','a'},
               data_size
           };
  fstream out("wave_write.wav",ios_base::binary|ios_base::out);
  out.write(reinterpret_cast<char*>(&header),sizeof(header));

  char *data = new char[data_size];

  if (channels == 1 && bps == 16) {
    short *mono16 = reinterpret_cast<short*>(data);
    const int MAX = (1 << 15) - 1;
    for (int i=0; i < frame_count; ++i)
      mono16[i] = short(MAX*sin(omega*i));
  }

  else if (channels == 2 && bps == 16) {
    short *stereo16 = reinterpret_cast<short*>(data);
    const int MAX = (1 << 15) - 1;
    for (int i=0; i < frame_count; ++i) {
      float x = (float(i)/frame_count),
            y = MAX*sin(omega*i);
      stereo16[2*i]   = short((1.0f - x)*y);
      stereo16[2*i+1] = short(x*y);
    }
  }

  else if (channels == 1 && bps == 8) {
    typedef unsigned char uchar;
    uchar *mono8 = reinterpret_cast<uchar*>(data);
    int MAX = (1 << 7) - 1;
    for (int i=0; i < frame_count; ++i)
      mono8[i] = uchar(MAX*sin(omega*i) + 128);
  }

  else if (channels == 2 && bps == 8) {
    typedef unsigned char uchar;
    uchar *stereo8 = reinterpret_cast<uchar*>(data);
    int MAX = (1 << 7) - 1;
    for (int i=0; i < frame_count; ++i) {
      float x = cos(2.0f*pi*float(i)/frame_count),
            y = MAX*sin(omega*i);
      stereo8[2*i]   = uchar(0.5*(1.0f+x)*y + 128);
      stereo8[2*i+1] = uchar(0.5*(1.0f-x)*y + 128);
    }
  }

  out.write(data,data_size);

  delete[] data;
  return 0;
}
