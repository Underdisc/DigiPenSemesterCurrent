// wave_read.cpp
// -- read format and data chunks (skip other chunks)
// jsh 1/18
//
// usage:
//   wave_read <file>


#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
using namespace std;


int main(int argc, char *argv[]) {
  if (argc != 2)
    return 0;

  fstream in(argv[1],ios_base::binary|ios_base::in);
  if (!in) {
    cout << "unable to open file" << endl;
    return -1;
  }

  struct { char label[4]; unsigned size; } chunk_head;
  char wave_tag[4];

  in.read(reinterpret_cast<char*>(&chunk_head),8);
  in.read(wave_tag,4);
  if (!in || strncmp(chunk_head.label,"RIFF",4) != 0
          || strncmp(wave_tag,"WAVE",4) != 0) {
    cout << "not a valid WAVE file" << endl;
    return 0;
  }

  // find format chunk
  in.read(reinterpret_cast<char*>(&chunk_head),8);
  while (in && strncmp(chunk_head.label,"fmt ",4) != 0) {
    in.seekg(chunk_head.size,ios_base::cur);
    in.read(reinterpret_cast<char*>(&chunk_head),8);
  }
  if (!in) {
    cout << "invalid or corrupted WAVE file: missing fmt-ck" << endl;
    return 0;
  }

  // dump format info
  char fmt[16];
  in.read(fmt,16);
  unsigned short format = *reinterpret_cast<unsigned short*>(fmt+0);
  unsigned short channels = *reinterpret_cast<unsigned short*>(fmt+2);
  unsigned rate = *reinterpret_cast<unsigned*>(fmt+4);
  unsigned short bits = *reinterpret_cast<unsigned short*>(fmt+14);
  cout << boolalpha;
  cout << "uncompressed data? " << (format == 1)
       << " [" << format << "]" << endl;
  cout << "number of channels: " << channels << endl;
  cout << "sampling rate: " << rate << endl;
  cout << "bits per sample: " << bits << endl;
  in.seekg(chunk_head.size-16,ios_base::cur);

  // find data chunk
  in.read(reinterpret_cast<char*>(&chunk_head),8);
  while (in && strncmp(chunk_head.label,"data",4) != 0) {
    in.seekg(chunk_head.size,ios_base::cur);
    in.read(reinterpret_cast<char*>(&chunk_head),8);
  }
  if (!in) {
    cout << "invalid or corrupted WAVE file: missing data-ck" << endl;
    return 0;
  }

  // dump data information
  unsigned count = (8*chunk_head.size)/(channels*bits);
  float duration = float(count)/float(rate);
  cout << "number of samples: " << count
       << " [" << duration << " seconds]" << endl;


  return 0;
}

