// BandPass2.h
// -- 12 dB/oct BP filter (improved)
// cs246 10/17

#ifndef CS246_BANDPASS_H
#define CS246_BANDPASS_H

#include "Filter.h"


class BandPass2 : public Filter {
  public:
    BandPass2(float f=0, float Q=1, float R=44100);
    void setFrequency(float f);
    void setQuality(float Q);
    float operator()(float x);
  private:
    void reset(void);
    double irate,
           frequency,
           quality,
           a0, b1, b2,
           x1, x2, y1, y2;
};


#endif

