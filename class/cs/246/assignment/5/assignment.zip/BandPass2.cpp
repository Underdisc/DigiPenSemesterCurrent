// BandPass2.cpp
// -- 12 dB/oct BP filter (improved)
// cs246 10/16

#include <cmath>
#include "BandPass2.h"
using namespace std;


BandPass2::BandPass2(float f, float Q, float R)
    : irate(1/R),
      frequency(f),
      quality(Q),
      x1(0), x2(0),
      y1(0), y2(0) {
  reset();
}


void BandPass2::setFrequency(float f) {
  frequency = f;
  reset();
}


void BandPass2::setQuality(float Q) {
  quality = Q;
  reset();
}


float BandPass2::operator()(float x) {
  double y = a0*(x-x2) + b1*y1 - b2*y2;
  x2 = x1;  x1 = x;
  y2 = y1;  y1 = y;
  return float(y);
}


void BandPass2::reset(void) {
  double const PI = 4.0*atan(1.0);
  double theta = tan(PI*frequency*irate),
         thetasq = theta*theta,
         norm = 1.0/(quality*thetasq + theta + quality);
  a0 = theta*norm;
  b1 = 2*quality*(1-thetasq)*norm;
  b2 = (quality*thetasq-theta+quality)*norm;
}

