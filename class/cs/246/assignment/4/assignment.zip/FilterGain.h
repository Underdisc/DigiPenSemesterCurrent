// FilterGain.h
// -- function to measure the gain of a filter
// cs246 10/17

#ifndef CS246_FILTERGAIN_H
#define CS246_FILTERGAIN_H

#include "Filter.h"


float filterGain(Filter& F, float f, float R);


#endif

