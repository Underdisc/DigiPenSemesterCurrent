Hello Professor Lin,

In your email, you said to take screen shots of the submission page in order
to see our grades on the three cs 375 assignments. These screen shots are in the
files listed below.

assignment1.png
assignment2.png
assignment3.png

The last file, assignment_totals.txt, lists all three of the grades along with
the final grade that results from them.

The code directory contains User1.cpp and User3.cpp. These are the files that 
were submitted for the last assignment.

Thanks,
Connor Deakin
