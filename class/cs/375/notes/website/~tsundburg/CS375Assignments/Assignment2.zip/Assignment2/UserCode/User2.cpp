/******************************************************************\
 * Author: 
 * Copyright 2015, DigiPen Institute of Technology
\******************************************************************/
#include "../Drivers/Driver2.hpp"

void RemoveWhitespaceAndComments(std::vector<Token>& tokens)
{
}

void Recognize(std::vector<Token>& tokens)
{
  throw ParsingException();
}
