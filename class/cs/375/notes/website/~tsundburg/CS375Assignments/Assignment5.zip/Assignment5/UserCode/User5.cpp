/******************************************************************\
 * Author: 
 * Copyright 2015, DigiPen Institute of Technology
\******************************************************************/
#include "../Drivers/Driver5.hpp"

void InterpreterPrePass(AbstractNode* node)
{
}

Interpreter* CreateInterpreter()
{
}

void DestroyInterpreter(Interpreter* interpreter)
{
}

Variant InterpreterFunctionCall(Interpreter* interpreter, Function* function, std::vector<Variant>& arguments)
{
}

void AddSinFunction(Library* library)
{
}
