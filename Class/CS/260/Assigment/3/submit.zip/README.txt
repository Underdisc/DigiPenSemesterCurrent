Run and Complile on Linux
  1. Run 'make' from the Build/ directory.
  2. Run 'make run' or './prog http://echo.cs260.net/test' (or whatever domain name you are testing with) to run the program.
