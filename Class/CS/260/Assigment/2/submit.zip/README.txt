Run and Complile on Linux
  1. Run 'make' from the Build/ directory.
  2. Run 'make run' or './prog' to run the program.
