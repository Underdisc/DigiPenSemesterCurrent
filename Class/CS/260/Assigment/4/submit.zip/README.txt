Run and Complile on Linux
  1. Run 'make' from the Build/ directory.
  2. Run './prog.exe [port-number]' to run the program.
