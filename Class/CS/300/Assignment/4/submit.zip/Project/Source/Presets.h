/* All content(c) 2017 - 2018 DigiPen(USA) Corporation, all rights reserved. */
#ifndef PRESETS_H
#define PRESETS_H

#define MESHPRESET "highpoly_sphere.obj"
#define DIFFUSEPRESET "diffuse.tga"
#define SPECULARPRESET "specular.tga"
#define NORMALPRESET "normal.png"

#endif // !PRESETS_H

