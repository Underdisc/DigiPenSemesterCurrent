#ifndef H_FRAMEBUFFER
#define H_FRAMEBUFFER

#include "Color.h"
#include "framework/Utilities.h"

namespace Graphics
{
  class ShaderProgram;
  class Texture;

  class Framebuffer
  {
  public:
    Framebuffer(u32 width, u32 height);

    inline u32 GetWidth() const { return width_; }
    inline u32 GetHeight() const { return height_; }

    inline u32 GetHandle() const { return fbo_; }

    inline void SetClearColor(Color const &color) { clearColor_ = color; }
    inline Color const &GetClearColor() const { return clearColor_; }

    void Build();
    void Bind(); // bind for rendering
    void Clear();
    inline std::shared_ptr<Texture> const &GetColorTexture()
    {
      return colorTexture_;
    }
    void Unbind();
    void Destroy();

  private:
    u32 width_, height_;
    u32 fbo_, depthRbo_;
    Color clearColor_;
    std::shared_ptr<Texture> colorTexture_;
  };
}

#endif
