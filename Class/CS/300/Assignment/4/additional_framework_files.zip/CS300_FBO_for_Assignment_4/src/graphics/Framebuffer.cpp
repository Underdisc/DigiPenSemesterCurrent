#include "Precompiled.h"
#include "framework/Debug.h"
#include "graphics/Color.h"
#include "graphics/Framebuffer.h"
#include "graphics/Texture.h"

namespace Graphics
{
  Framebuffer::Framebuffer(u32 width, u32 height)
    : width_(width), height_(height), fbo_(NULL), depthRbo_(NULL),
    colorTexture_(NULL), clearColor_(Color::Black)
  {
  }

  void Framebuffer::Build()
  {
    // build texture
    u8 *data = new u8[width_ * height_ * 4];
    std::memset(data, 0xffffffff, sizeof(u8) * width_ * height_ * 4);
    colorTexture_ = std::make_shared<Texture>(
      data, width_, height_, Texture::Format::RGBA);
    colorTexture_->Build();
    // build framebuffer, and renderbuffer
    glGenFramebuffers(1, &fbo_);
    glGenRenderbuffers(1, &depthRbo_);
    // fill in renderbuffer
    glBindRenderbuffer(GL_RENDERBUFFER, depthRbo_);
    glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT24,
      width_, height_);
    // link framebuffer
    Bind();
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D,
      colorTexture_->GetTextureHandle(), 0);
    glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT,
      GL_RENDERBUFFER, depthRbo_);
    // verify it worked
    GLenum status = glCheckFramebufferStatus(GL_FRAMEBUFFER);
    Assert(status == GL_FRAMEBUFFER_COMPLETE, "Failed to create framebuffer.");
    glViewport(0, 0, width_, height_);
    glClearColor(0.f, 0.f, 0.f, 1.f); // default clear color
    glClearDepth(1.f); // default clear depth
    Unbind();
  }

  void Framebuffer::Bind()
  {
    glBindFramebuffer(GL_FRAMEBUFFER, fbo_);
    glViewport(0, 0, width_, height_);
    WarnIf(fbo_ == NULL, "Warning: Binding unbuilt framebuffer.");
  }

  void Framebuffer::Clear()
  {
    glClearColor(clearColor_.r, clearColor_.g, clearColor_.b, clearColor_.a);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  }

  void Framebuffer::Unbind()
  {
    glBindFramebuffer(GL_FRAMEBUFFER, 0); // bind screen framebuffer
  }

  void Framebuffer::Destroy()
  {
    Unbind();
    colorTexture_->Destroy();
    glDeleteRenderbuffers(1, &depthRbo_);
    glDeleteFramebuffers(1, &fbo_);
    fbo_ = NULL;
    depthRbo_ = NULL;
    colorTexture_ = NULL; // deletes it
  }
}
