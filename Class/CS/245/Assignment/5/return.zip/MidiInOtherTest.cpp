// MidiInOtherTest.cpp
// -- another test driver for the MidiIn class
// jsh 2/18
//
// usage:
//   MidiInOtherTest [<n>]
// where:
//   <n> -- (optional) MIDI input device number

#include <iostream>
#include <ctime>
#include <cstdlib>
#include "MidiIn.h"
using namespace std;


struct PrintMsg : MidiIn {
  bool zero_volume;
  PrintMsg(int devno);
  ~PrintMsg(void);
  void onNoteOn(int channel, int note, int velocity);
  void onNoteOff(int channel, int note);
  void onPitchWheelChange(int channel, float value);
  void onVolumeChange(int channel, int level);
  void onModulationWheelChange(int channel, int value);
  void onControlChange(int channel, int number, int value);
};


PrintMsg::PrintMsg(int n)
    : MidiIn(n),
      zero_volume(false) {
  start();
}


PrintMsg::~PrintMsg(void) {
  stop();
}


void PrintMsg::onNoteOn(int channel, int note, int velocity) {
  cout << "onNoteOn: " << channel << ' ' << note << ' ' << velocity << endl;
}


void PrintMsg::onNoteOff(int channel, int note) {
  cout << "onNoteOff: " << channel << ' ' << note << endl;
}


void PrintMsg::onPitchWheelChange(int channel, float value) {
  cout << "onPichWheelChange: " << channel << ' ' << value << endl;
}


void PrintMsg::onVolumeChange(int channel, int level) {
  cout << "onVolumeChange: " << channel << ' ' << level << endl;
  zero_volume = (level == 0);
}


void PrintMsg::onModulationWheelChange(int channel, int value) {
  cout << "onModulationWheelChange: " << channel << ' ' << value << endl;
}


void PrintMsg::onControlChange(int channel, int number, int value) {
  cout << "onControlChange: " << channel << ' '
       << number << ' ' << value << endl;
}


int main(int argc, char *argv[]) {
  if (argc == 1) {
    cout << MidiIn::getDeviceInfo() << endl;
    return 0;
  }

  if (argc != 2)
    return 0;

  int devno = atoi(argv[1]);

  try {
    PrintMsg print_msg(devno);
    while (!print_msg.zero_volume);
  }

  catch (...) {
    cout << "device " << devno << " not available" << endl;
  }

  return 0;
}

