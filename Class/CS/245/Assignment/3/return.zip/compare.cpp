// compare.cpp
// -- compare two wave files
// jsh 9/09

#include <iostream>
#include <fstream>
#include <algorithm>
#include <cmath>
using namespace std;


int main(int argc, char *argv[]) {
  if (argc != 3)
    return 0;

  const int count = 2;
  fstream in[count];
  char header[count][44];
  unsigned file_size[count];
  unsigned data_size[count];
  unsigned short bit_rate[count];
  unsigned sample_rate[count];
  unsigned short channels[count];
  unsigned block_size[count];
  char *data[count];

  for (int i=0; i < count; ++i) {
    in[i].open(argv[i+1],ios_base::in|ios_base::binary);
    in[i].read(header[i],44);
    file_size[i] = *reinterpret_cast<unsigned*>(header[i]+4);
    bit_rate[i] = *reinterpret_cast<unsigned short*>(header[i]+34);
    sample_rate[i] = *reinterpret_cast<unsigned*>(header[i]+24);
    channels[i] = *reinterpret_cast<unsigned short*>(header[i]+22);
    data_size[i] = *reinterpret_cast<unsigned*>(header[i]+40);
    block_size[i] = *reinterpret_cast<unsigned*>(header[i]+28);
    data[i] = new char[data_size[i]];
    in[i].read(data[i],data_size[i]);
  }

  bool okay = true;
  for (int j=0; okay && j < 40; ++j)
    okay = (header[0][j] == header[1][j]);
  if (!okay)
    cout << "  ** header mismatch" << endl;
  if (bit_rate[0] != bit_rate[1]) {
    cout << "  ** bit rate mismatch: " << bit_rate[1]
         << " (" << bit_rate[0] << ")" << endl;
    okay = false;
  }
  if (sample_rate[0] != sample_rate[1]) {
    cout << "  ** sample rate mismatch: " << sample_rate[1]
         << " (" << sample_rate[0] << ")" << endl;
    okay = false;
  }
  if (channels[0] != channels[1]) {
    cout << "  ** channel number mismatch: " << channels[1]
         << " (" << channels[0] << ")" << endl;
    okay = false;
  }
  if (data_size[0] != data_size[1]) {
    cout << "  ** data size mismatch: " << data_size[1]
         << " (" << data_size[0] << ")" << endl;
    okay = false;
  }
  if (file_size[0] != data_size[0]+36) {
    cout << "  ** inconsistent file size: " << file_size[0]
         << " (" << (data_size[0]+32) << ")" << endl;
    okay = false;
  }
  if (file_size[1] != data_size[1]+36) {
    cout << "  ** inconsistent file size: " << file_size[1]
         << " (" << (data_size[1]+32) << ")" << endl;
    okay = false;
  }
  if (block_size[0] != block_size[1]) {
    cout << "  ** block size (bytes/sec) mismatch: " << block_size[1]
         << " (" << block_size[0] << ")" << endl;
    okay = false;
  }
  float rms = 0.0f,
        peak[2] = {0.0f, 0.0f};
  unsigned sample_count[2] = {data_size[0]/(bit_rate[0]/8),
                              data_size[1]/(bit_rate[0]/8)};

  if (bit_rate[0] == 16) {
    short *sample[2] = {reinterpret_cast<short*>(data[0]),
                        reinterpret_cast<short*>(data[1])};
    for (unsigned j=0; j < sample_count[0]; ++j) {
      float sample_1j = (j < sample_count[1]) ? sample[1][j] : 0.0f;
      float diff = sample[0][j] - sample_1j;
      rms += diff*diff;
      if (abs(sample[0][j]) > peak[0])
        peak[0] = abs(sample[0][j]);
      if (abs(sample_1j) > peak[1])
        peak[1] = abs(sample_1j);
    }
  }

  else if (bit_rate[0] == 8) {
    unsigned char *sample[2] = {reinterpret_cast<unsigned char*>(data[0]),
                                reinterpret_cast<unsigned char*>(data[1])};
    float mid = ((1<<7)-1);
    for (unsigned j=0; j < sample_count[0]; ++j) {
      float sample_0j = sample[0][j] - mid,
            sample_1j = (j < sample_count[1]) ? sample[1][j]-mid : 0.0f;
      float diff = sample_0j - sample_1j;
      rms += diff*diff;
      if (abs(sample[0][j]) > peak[0])
        peak[0] = abs(sample_0j);
      if (abs(sample_1j) > peak[1])
        peak[1] = abs(sample_1j);
    }
  }

  rms = sqrt(rms/sample_count[0]);
  if (rms > 0.001f)
    cout << "  RMS difference = " << rms << endl;
  else
    cout << "  files are similar" << endl;

  for (int i=0; i < count; ++i)
    delete[] data[i];
  return 0;
}

