HW4
Connor Deakin
13/02/2018

The images contain the work done for the problems in homework 4.
