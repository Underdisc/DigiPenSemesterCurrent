How to run this executable.
1. Double click the executable (prog.exe) and a command prompt will appear.
2. Type in the problem number and press enter. The problem numbers correspond directly to the instruction handout.
3. The executable will bring up prompts asking inputs. Just follow these prompts to use the program.

Notes
- Only enter complete lines for input. For example, do not use the following for problem number 2.
ZNGURZNGVPFNFNARKCERFFVBABSGURUHZNAZVAQERSYRPGFGUR
NPGVIRJVYYGURPBAGRZCYNGVIRERNFBANAQGURQRFVERSBENRF
GURGVPCRESRPGVBAVGFONFVPRYRZRAGFNERYBTVPNAQVAGHVGV
BANANYLFVFNAQPBAFGEHPGVBATRARENYVGLNAQVAQVIVQHNYVGL
Instead, use this for input.
ZNGURZNGVPFNFNARKCERFFVBABSGURUHZNAZVAQERSYRPGFGURNPGVIRJVYYGURPBAGRZCYNGVIRERNFBANAQGURQRFVERSBENRFGURGVPCRESRPGVBAVGFONFVPRYRZRAGFNERYBTVPNAQVAGHVGVBANANYLFVFNAQPBAFGEHPGVBATRARENYVGLNAQVAQVIVQHNYVGL
This is true for all other inputs, however, it will likely only become a problem on problem 2.
