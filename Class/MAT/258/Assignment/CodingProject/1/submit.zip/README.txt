How to run this executable.
1. Double click the executable (prog.exe) and a command prompt will appear.
2. Type in the problem number and press enter. The problem numbers correspond directly to the instruction handout.
3. The executable will bring up prompts asking inputs. Just follow these prompts to use the program.
